/*
  SafeWire — Firmware ESP32 / ESP8266 + DS18B20
  -----------------------------------------------------------------
  Lê a temperatura do sensor DS18B20 (pino GPIO 4) e envia via HTTP
  POST em formato JSON para o servidor SafeWire (server.js), a cada
  3 segundos.

  Bibliotecas necessárias (instalar pela Arduino IDE > Gerenciador
  de Bibliotecas):
    - OneWire            (Paul Stoffregen)
    - DallasTemperature   (Miles Burton)
  Para ESP32, a biblioteca "WiFi.h" e "HTTPClient.h" já vêm com o
  core "ESP32" (instale via Gerenciador de Placas). Para ESP8266,
  troque os includes conforme indicado abaixo.
  -----------------------------------------------------------------
*/

// ---------- Selecione a placa alterando estas duas linhas ----------
#define USE_ESP32   1   // 1 = ESP32 | 0 = ESP8266

#if USE_ESP32
  #include <WiFi.h>
  #include <HTTPClient.h>
#else
  #include <ESP8266WiFi.h>
  #include <ESP8266HTTPClient.h>
  #include <WiFiClient.h>
#endif

#include <OneWire.h>
#include <DallasTemperature.h>

/* ====================== CONFIGURAÇÕES DO USUÁRIO ======================
   Ajuste estes valores antes de gravar o firmware.
   ======================================================================= */

// --- Wi-Fi ---
const char* WIFI_SSID     = "NOME_DA_SUA_REDE_WIFI";
const char* WIFI_PASSWORD = "SENHA_DA_SUA_REDE_WIFI";

// --- Servidor SafeWire ---
// IP do computador onde o server.js está rodando na mesma rede local.
// Descubra com "ipconfig" (Windows) ou "ifconfig"/"ip a" (Linux/Mac).
const char* SERVER_HOST = "192.168.0.100";   // <-- ajuste para o IP do seu PC
const int   SERVER_PORT = 3000;
const char* SERVER_PATH = "/api/temperature";

// --- Identificação do dispositivo/tomada ---
// Token da conta (copiado da tela Configurações do dashboard SafeWire).
const char* USER_TOKEN = "sw_live_XXXXXXXXXX";
// ID da tomada monitorada por ESTE dispositivo (deve bater com o
// "ID do dispositivo" cadastrado no dashboard, ex.: SW-001).
const char* DEVICE_ID  = "SW-001";

// --- Pino do sensor DS18B20 ---
#define ONE_WIRE_BUS 4   // GPIO 4

// --- Intervalo de envio ---
const unsigned long SEND_INTERVAL_MS = 3000; // 3 segundos

/* ====================================================================== */

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

unsigned long lastSendTime = 0;

void connectWiFi() {
  Serial.print("Conectando ao Wi-Fi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("Wi-Fi conectado. IP do dispositivo: ");
  Serial.println(WiFi.localIP());
}

void sendTemperature(float temperature) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi desconectado — tentando reconectar...");
    connectWiFi();
    return;
  }

  WiFiClient client;
  HTTPClient http;

  String url = String("http://") + SERVER_HOST + ":" + String(SERVER_PORT) + SERVER_PATH;
  http.begin(client, url);
  http.addHeader("Content-Type", "application/json");

  // Monta o payload JSON no formato esperado pelo server.js
  unsigned long ts = (unsigned long) millis(); // ideal: sincronizar com NTP em produção
  String payload = String("{")
    + "\"user_token\":\"" + USER_TOKEN + "\","
    + "\"device_id\":\"" + DEVICE_ID + "\","
    + "\"temperature\":" + String(temperature, 1) + ","
    + "\"timestamp\":" + String((unsigned long) (millis()))
    + "}";

  Serial.print("Enviando: ");
  Serial.println(payload);

  int httpCode = http.POST(payload);

  if (httpCode > 0) {
    Serial.printf("Resposta do servidor: %d\n", httpCode);
    String response = http.getString();
    Serial.println(response);
  } else {
    Serial.printf("Falha no POST. Erro: %s\n", http.errorToString(httpCode).c_str());
  }

  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);

  sensors.begin();
  connectWiFi();
}

void loop() {
  unsigned long now = millis();

  if (now - lastSendTime >= SEND_INTERVAL_MS) {
    lastSendTime = now;

    sensors.requestTemperatures();
    float tempC = sensors.getTempCByIndex(0);

    if (tempC == DEVICE_DISCONNECTED_C) {
      Serial.println("Erro: sensor DS18B20 não encontrado/desconectado.");
      return;
    }

    Serial.print("Temperatura lida: ");
    Serial.print(tempC);
    Serial.println(" °C");

    sendTemperature(tempC);
  }
}
